<?php
error_log("[[MB]] GLOBAL MU BOOT");
if (function_exists("header")) { @header("X-MB-OK: global"); }
